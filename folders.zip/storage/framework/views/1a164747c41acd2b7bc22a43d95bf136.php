

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Дизайн интерьера')); ?></div>

                <div class="card-body">
                    <!-- Name (Russian) -->
                    <div class="form-group">
                        <label><?php echo e(__('Название (русский)')); ?></label>
                        <p><?php echo e($Interier_design->name_ru); ?></p>
                    </div>

                    <!-- Name (Uzbek) -->
                    <div class="form-group">
                        <label><?php echo e(__('Название (узбекский)')); ?></label>
                        <p><?php echo e($Interier_design->name_uz); ?></p>
                    </div>

                    <!-- Description (Russian) -->
                    <div class="form-group">
                        <label><?php echo e(__('Описание (русский)')); ?></label>
                        <p><?php echo $Interier_design->description_ru; ?></p>
                    </div>

                    <!-- Description (Uzbek) -->
                    <div class="form-group">
                        <label><?php echo e(__('Описание (узбекский)')); ?></label>
                        <p><?php echo $Interier_design->description_uz; ?></p>
                    </div>

                    <!-- Image -->
                    <?php if($Interier_design->image_path): ?>
                        <div class="form-group">
                            <label><?php echo e(__('Изображение')); ?></label>
                            <div>
                                <img src="<?php echo e(asset($Interier_design->image_path)); ?>" alt="<?php echo e($Interier_design->name_ru); ?>" class="img-fluid">
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- Tags (Russian) -->
                    <div class="form-group">
                        <label><?php echo e(__('Теги (русский)')); ?></label>
                        <p><?php echo e($Interier_design->tags_ru); ?></p>
                    </div>

                    <!-- Tags (Uzbek) -->
                    <div class="form-group">
                        <label><?php echo e(__('Теги (узбекский)')); ?></label>
                        <p><?php echo e($Interier_design->tags_uz); ?></p>
                    </div>

                    <a href="<?php echo e(route('interier_designs.index')); ?>" class="btn btn-secondary"><?php echo e(__('Назад к списку')); ?></a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\developer\real projects\Euro Light\hosting Euro_light\Euro_Light\resources\views/admin/interier_designs/show.blade.php ENDPATH**/ ?>