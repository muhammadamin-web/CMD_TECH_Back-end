<!-- resources/views/categories/show.blade.php -->


<?php $__env->startSection('content'); ?>
    <!-- <div class="container">
        <h1><?php echo e($category->name_ru); ?></h1>
        <h2><?php echo e($category->name_uz); ?></h2>

        <?php if($category->image_path): ?>
            <img src="<?php echo e($category->image_path); ?>" alt="<?php echo e($category->name_ru); ?>" style="max-width: 300px;">
        <?php endif; ?>

    </div> -->
    <div class="product_show" style="margin-top: 0;">
    
    <h2 class="product_show_title"><p><?php echo e($category->name_uz); ?></p>  <br><p><?php echo e($category->name_ru); ?></p></h2>
    <img src="<?php echo e($category->image_path); ?>" alt="" class="product_show_img">
    <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-secondary" style="margin-top:50px; margin-left:60px;">Вернуться к категориям</a>
  </div>   

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\developer\real projects\hosting Euro_light\Euro_Light\resources\views/admin/categories/show.blade.php ENDPATH**/ ?>