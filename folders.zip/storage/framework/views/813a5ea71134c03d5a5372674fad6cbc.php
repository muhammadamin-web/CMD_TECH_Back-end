

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Продукты')); ?>

                <a href="<?php echo e(route('products.create')); ?>" class="btn btn-sm btn-primary float-right"><?php echo e(__('Создать продукты')); ?></a>

                </div>
                <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th><?php echo e(__('Имя')); ?></th>
                            <th><?php echo e(__('Категория')); ?></th>
                            <th><?php echo e(__('Изображение')); ?></th>
                            <th><?php echo e(__('Действия')); ?></th>

                            <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($product->name_uz); ?></td>
                                <td><?php echo e($product->category->name_uz); ?></td>
                                <td>
                                    <?php if($product->image_path): ?>
                                    <img src="<?php echo e(asset($product->image_path)); ?>" alt="<?php echo e($product->name_uz); ?>" width="50">
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Редактировать')); ?></a>
                                    <a href="<?php echo e(route('products.show', $product->id)); ?>" class="btn btn-sm btn-primary">Показывать</a>
                                    <form method="POST" action="<?php echo e(route('products.destroy', $product->id)); ?>" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger"><?php echo e(__('Удалить')); ?></button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\developer\real projects\Euro Light\hosting Euro_light\Euro_Light\resources\views/admin/products/index.blade.php ENDPATH**/ ?>