

<?php $__env->startSection('content'); ?>

<div class="product_show">
    
    <h2 class="product_show_title"><p><?php echo e($product->category->name_ru); ?></p>/<p><?php echo e($product->name_ru); ?></p></h2>
    <img src="<?php echo e(asset($product->image_path)); ?>" alt="" class="product_show_img">
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\developer\real projects\hosting Euro_light\Euro_Light\resources\views/admin/products/show.blade.php ENDPATH**/ ?>