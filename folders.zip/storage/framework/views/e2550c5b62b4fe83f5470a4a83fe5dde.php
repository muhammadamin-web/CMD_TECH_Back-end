

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2><?php echo e(__('Список проектов')); ?></h2>
    <a href="<?php echo e(route('projects.create')); ?>" class="btn btn-primary" style="float: right; margin-bottom:20px;"><?php echo e(__('Add New Project')); ?></a>
    <table class="table table-striped mt-3">
        <thead>
            <tr>
                <th><?php echo e(__('Название RU')); ?></th>
                <th><?php echo e(__('Название УЗ')); ?></th>
                <th>img</th>
                <th><?php echo e(__('Действия')); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($project->name_ru); ?></td>
                <td><?php echo e($project->name_uz); ?></td>
                <td> <img src="<?php echo e(asset($project->image_path)); ?>" alt="<?php echo e($project->image_name); ?>" class="img-fluid" width="50"></td>
                <td>
                    <a href="<?php echo e(route('projects.show', $project)); ?>" class="btn btn-sm btn-info"><?php echo e(__('Показывать')); ?></a>
                    <a href="<?php echo e(route('projects.edit', $project)); ?>" class="btn btn-sm btn-warning"><?php echo e(__('Редактировать')); ?></a>
                    <form action="<?php echo e(route('projects.destroy', $project)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-sm btn-danger"><?php echo e(__('Удалить')); ?></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\developer\real projects\Euro Light\hosting Euro_light\Euro_Light\resources\views/admin/projects/index.blade.php ENDPATH**/ ?>