

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2><?php echo e(__('Project Details')); ?></h2>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title"><?php echo e(__('Название RU')); ?>: <?php echo e($project->name_ru); ?></h5>
            <h5 class="card-title"><?php echo e(__('Название УЗ')); ?>: <?php echo e($project->name_uz); ?></h5>
            <?php if($project->image_path): ?>
                <img src="<?php echo e(asset($project->image_path)); ?>" alt="<?php echo e($project->image_name); ?>" class="img-fluid">
            <?php endif; ?>
        </div>
    </div>
    <a href="<?php echo e(route('projects.index')); ?>" class="btn btn-primary mt-3"><?php echo e(__('Вернуться к проектам')); ?></a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\developer\real projects\hosting Euro_light\Euro_Light\resources\views/admin/projects/show.blade.php ENDPATH**/ ?>