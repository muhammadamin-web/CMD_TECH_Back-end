

<?php $__env->startSection('content'); ?>

<!-- <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Products')); ?>

                <a href="<?php echo e(route('products.create')); ?>" class="btn btn-sm btn-primary float-right"><?php echo e(__('Create Products')); ?></a>

                </div>
                <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th><?php echo e(__('Name')); ?></th>
                            <th><?php echo e(__('Category')); ?></th>
                            <th><?php echo e(__('Image')); ?></th>
                            <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($product->{'name_' . app()->getLocale()}); ?></td>
                                <td><?php echo e($product->category->{'name_' . app()->getLocale()}); ?></td>
                                <td>
                                    <?php if($product->image_path): ?>
                                    <img src="<?php echo e(asset($product->image_path)); ?>" alt="<?php echo e($product->name_uz); ?>" width="50">
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('product.show', ['locale' => app()->getLocale(), 'product' => $product->id])); ?>" class="btn btn-sm btn-primary">Show</a>
                                    <form method="POST" action="<?php echo e(route('products.destroy', $product->id)); ?>" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                       </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div> -->
<div class="product_page_container">
    <h2 class="product_page_title"><?php echo e(__('app.products')); ?></h2>
    <div class="cards_container">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


      <a href="<?php echo e(route('product.show', ['locale' => app()->getLocale(), 'product' => $product->id])); ?>">
        <div class="product_page_card">
                <img src="<?php echo e(asset($product->image_path)); ?>" alt="">
       
          <h4 class="product_card_text"><?php echo e($product->{'name_' . app()->getLocale()}); ?></h4>
        </div>
      </a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\developer\real projects\hosting Euro_light\Euro_Light\resources\views/products/index.blade.php ENDPATH**/ ?>