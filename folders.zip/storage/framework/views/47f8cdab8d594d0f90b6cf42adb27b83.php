<!-- resources/views/layouts/app.blade.php -->

<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <!-- CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">

    <title><?php echo e(' Euro Light'); ?></title>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">
    <!-- <link rel="stylesheet" href="<?php echo e(asset('css/product.css')); ?>"> -->

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>





    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://cdn.ckeditor.com/ckeditor5/34.2.0/classic/ckeditor.js"></script>

        <!-- Bootstrap CSS -->
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">


        <style>
                        .ck-content img {
    display: block;
    margin-left: auto;
    margin-right: auto;
}

          .form-group textarea img {
    max-height: 200px;
    width: auto;
}
.ck-content img {
    max-height: 400px;
}
    .image img {
        text-align: center ;
        margin-left: auto;
margin-right: auto;
display: block;
        max-height: 300px;
        object-fit: cover;
    }
.card-body{
    display: block;
}.ck-content img {
    max-height: 400px;
}
.card-body p img{
    text-align: center;
    max-width: 80%;
    max-height: 400px;
}
        </style>
</head>

<body>
<div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                   Euro Light
                </a>


                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('products.index')); ?>"><?php echo e(__('Продукты')); ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('categories.index')); ?>"><?php echo e(__('Категории')); ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('projects.index')); ?>"><?php echo e(__('Проекты')); ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('interier_designs.index')); ?>"><?php echo e(__('Интерьер Дизайн')); ?></a>
                        </li>
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ms-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Авторизоваться')); ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?>

                                </a>

                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
    <script>
ClassicEditor
    .create(document.querySelector('#description_uz'), {
        ckfinder: {
            uploadUrl: '<?php echo e(route("ckeditor.upload").'?_token='.csrf_token()); ?>'
        },
        
        on: {
            instanceReady: function (event) {
                this.dataProcessor.htmlFilter.addRules({
                    elements: {
                        img: function (el) {
                            el.attributes.style = 'max-height:400px; display: block; margin-left: auto; margin-right: auto;';
                        }
                    }
                });
            }
        }
    })
    .catch(error => {
        console.error(error);
    });

ClassicEditor
    .create(document.querySelector('#description_ru'), {
        ckfinder: {
            uploadUrl: '<?php echo e(route("ckeditor.upload").'?_token='.csrf_token()); ?>'
        },
        
        on: {
            instanceReady: function (event) {
                this.dataProcessor.htmlFilter.addRules({
                    elements: {
                        img: function (el) {
                            el.attributes.style = 'max-height:400px; display: block; margin-left: auto; margin-right: auto;';
                        }
                    }
                });
            }
        }
    })
    .catch(error => {
        console.error(error);
    });

</script>
        <!-- Bootstrap JS and jQuery -->
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="ckeditor.js"></script>
</body>

</html><?php /**PATH D:\personal\developer\real projects\Euro Light\hosting Euro_light\Euro_Light\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>