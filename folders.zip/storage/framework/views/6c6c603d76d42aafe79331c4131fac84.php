

<?php $__env->startSection('content'); ?>


<div class="product_page_container">
    <h2 class="product_page_title"><?php echo e(__('app.products')); ?></h2>
    <div class="cards_container">
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


    <a href="<?php echo e(route('product.show', ['locale' => app()->getLocale(), 'slug' => $product->{'slug_' . app()->getLocale()}])); ?>">
        <div class="product_page_card">
                <img src="<?php echo e(asset($product->image_path)); ?>" alt="">
       
          <h4 class="product_card_text"><?php echo e($product->{'name_' . app()->getLocale()}); ?></h4>
        </div>
      </a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\developer\real projects\Euro Light\hosting Euro_light\Euro_Light\resources\views/products/index.blade.php ENDPATH**/ ?>