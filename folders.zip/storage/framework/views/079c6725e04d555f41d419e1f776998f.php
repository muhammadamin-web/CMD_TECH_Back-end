
<?php $__env->startSection('meta'); ?>
<meta name="keywords" content="<?php echo e($product->{'tags_' . app()->getLocale()}); ?>,люстра в ташкенте, qandillar, свечи, qandillar do'koni, свечной магазин, qandillar narxi, цена на свечи, qandillar xususiyatlari, свечи особенности, qandillar turlari, виды свечей, qandillar qanday ishlatiladi, как использовать свечи, qandillar qanday tozalaydi, как очистить свечи, qandillar va salomatlik, свечи и здоровье, qandillar va madaniyat, свечи и культура, qandillar va san'at, свечи и искусство, qandillar va hayvonlar, свечи и животные, qandillar va yodgorlik, свечи и память, qandillar sotib olish, купить свечи, qandillar hisobi, расчет свечей">
<meta name="description" content="<?php echo e($product->{'meta_description_' . app()->getLocale()}); ?>">
<meta property="og:title" content="<?php echo e($product->{'name_' . app()->getLocale()}); ?>">
<meta property="og:description" content="<?php echo e($product->{'meta_description_' . app()->getLocale()}); ?>">
<title>Euro Light - <?php echo e($product->{'name_' . app()->getLocale()}); ?></title>
<link rel="stylesheet" href="<?php echo e(asset('css/product_detail.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/product.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/interier_detail.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="interier_detail">
  <p class="interyer_title"><?php echo e(__('app.categories')); ?> ><a style="color: black;" href="<?php echo e(route('category.show', ['locale' => app()->getLocale(), 'slug' => $product->category->{'slug_' . app()->getLocale()}])); ?>">
  <?php echo e($product->category->{'name_' . app()->getLocale()}); ?>

</a> </p>
  <div class="interier_detail_container">
    <h1 class="interier_detail_title"><?php echo e($product->{'name_' . app()->getLocale()}); ?></h1>
  </div>
  <img src="<?php echo e(asset($product->image_path)); ?>" alt="" class="interier_detail_img">
  <p class="image_alt"><?php echo e($product->{'meta_description_' . app()->getLocale()}); ?></p>

  <div class="interier_detail_description">
  <p><?php echo $product->{'description_' . app()->getLocale()}; ?></p>
  </div>
</div>
<div class="container_product">
  <h1 class="product_pag_service">Другие продукты</h1>
  <div class="card_container">
    <?php $__currentLoopData = $products_footer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="card" onclick="raiseText()">
      <img src="<?php echo e(asset($products->image_path)); ?>" alt="Card Image">
      <div class="card-info">
        <p class="card-info_title"><?php echo e($products->{'name_' . app()->getLocale()}); ?></p>
        <div class="card_button_container">
          <a href="" class="card_button"><?php echo e(__('app.more_button')); ?></a>
        </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\developer\real projects\Euro Light\hosting Euro_light\Euro_Light\resources\views/products/show.blade.php ENDPATH**/ ?>