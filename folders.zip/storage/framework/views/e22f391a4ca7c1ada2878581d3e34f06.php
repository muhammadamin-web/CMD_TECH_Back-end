

<?php $__env->startSection('content'); ?>
<!-- <div class="container">
    <h2><?php echo e(__('Projects List')); ?></h2>
    <a href="<?php echo e(route('projects.create')); ?>" class="btn btn-primary"><?php echo e(__('Add New Project')); ?></a>
    <table class="table table-striped mt-3">
        <thead>
            <tr>
                <th><?php echo e(__('ID')); ?></th>
                <th><?php echo e(__('Name RU')); ?></th>
                <th><?php echo e(__('Name UZ')); ?></th>
                <th><?php echo e(__('Actions')); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($project->id); ?></td>
                <td><?php echo e($project->name_ru); ?></td>
                <td><?php echo e($project->name_uz); ?></td>
                <td>
                    <a href="<?php echo e(route('projects.show', $project)); ?>" class="btn btn-sm btn-info"><?php echo e(__('View')); ?></a>
                    <a href="<?php echo e(route('projects.edit', $project)); ?>" class="btn btn-sm btn-warning"><?php echo e(__('Edit')); ?></a>
                    <form action="<?php echo e(route('projects.destroy', $project)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-sm btn-danger"><?php echo e(__('Delete')); ?></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div> -->
<div class="projects page" id="projects">
    <h2 class="lang" key="projects"><?php echo e(__('app.projects')); ?></h2>


    <div class="projects_container">
        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('project.show', ['locale' => app()->getLocale(), 'project' => $project->id])); ?>" class="project_card">

            <div class="project_img_wrapper">
                <img class="project_inner-img" src="<?php echo e(asset($project->image_path)); ?>">
                <div class="project_middle">
                    <div class="project_text lang" key="projects1"><?php echo e($project->{'name_' . app()->getLocale()}); ?></div>
                </div>
            </div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\developer\real projects\hosting Euro_light\Euro_Light\resources\views/projects/index.blade.php ENDPATH**/ ?>