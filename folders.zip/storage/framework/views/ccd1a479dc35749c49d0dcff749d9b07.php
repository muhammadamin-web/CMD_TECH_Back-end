

<?php $__env->startSection('content'); ?>
<div class="about" id="about" style="margin-top:50px;">
    <h2 class="lang" key="about"><?php echo e(__('app.about')); ?></h2>
    <div class="container">
      <img src="<?php echo e(asset('images/static_img/about.jpg')); ?>" alt="">
      <h5 class="lang" key="about_text"><?php echo e(__('app.about_text')); ?></h5>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\developer\real projects\hosting Euro_light\Euro_Light\resources\views/about.blade.php ENDPATH**/ ?>