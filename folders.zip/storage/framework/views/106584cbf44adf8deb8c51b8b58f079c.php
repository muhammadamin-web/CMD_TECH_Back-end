

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2><?php echo e(__('Изменить проект')); ?></h2>
    <form action="<?php echo e(route('projects.update', $project->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="name_ru"><?php echo e(__('Название RU')); ?></label>
            <input type="text" class="form-control" id="name_ru" name="name_ru" value="<?php echo e($project->name_ru); ?>" required>
        </div>
        <div class="form-group">
            <label for="name_uz"><?php echo e(__('Название УЗ')); ?></label>
            <input type="text" class="form-control" id="name_uz" name="name_uz" value="<?php echo e($project->name_uz); ?>" required>
        </div>
        <!-- Description (Russian) -->
        <div class="form-group">
            <label for="description_ru"><?php echo e(__('Описание (рус.)')); ?></label>
            <textarea id="description_ru" class="form-control <?php $__errorArgs = ['description_ru'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="description_ru"><?php echo e(old('description_ru', $project->description_ru)); ?></textarea>
            <?php $__errorArgs = ['description_ru'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>

        <!-- Description (Uzbek) -->
        <div class="form-group">
            <label for="description_uz"><?php echo e(__('Описание (узбекское)')); ?></label>
            <textarea id="description_uz" class="form-control <?php $__errorArgs = ['description_uz'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="description_uz"><?php echo e(old('description_uz', $project->description_uz)); ?></textarea>
            <?php $__errorArgs = ['description_uz'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>

        <!-- Tags (Russian) -->
        <div class="form-group">
            <label for="tags_ru"><?php echo e(__('Теги (рус.)')); ?></label>
            <input id="tags_ru" type="text" class="form-control <?php $__errorArgs = ['tags_ru'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tags_ru" value="<?php echo e(old('tags_ru', $project->tags_ru)); ?>">
            <?php $__errorArgs = ['tags_ru'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>

        <!-- Tags (Uzbek) -->
        <div class="form-group">
            <label for="tags_uz"><?php echo e(__('Теги (узбекское)')); ?></label>
            <input id="tags_uz" type="text" class="form-control <?php $__errorArgs = ['tags_uz'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tags_uz" value="<?php echo e(old('tags_uz', $project->tags_uz)); ?>">
            <?php $__errorArgs = ['tags_uz'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>
        <div class="form-group">
                    <label for="image_path"><?php echo e(__('Изображение')); ?></label>
                    <?php if($project->image_path): ?>
                    <img src="<?php echo e(asset($project->image_path)); ?>" alt="<?php echo e($project->name); ?>" width="100" class="mb-2">
                    <?php endif; ?>
                    <input id="image_path" type="file" class="form-control-file <?php $__errorArgs = ['image_path'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="image_path" accept="image/*">
                    <?php $__errorArgs = ['image_path'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
                <div class="form-group mb-0">
                    <button type="submit" class="btn btn-primary">
                        <?php echo e(__('Обновлять')); ?>

                    </button>
                    <a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary">
                        <?php echo e(__('Отмена')); ?>

                    </a>
                </div>    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\developer\real projects\Euro Light\hosting Euro_light\Euro_Light\resources\views/admin/projects/edit.blade.php ENDPATH**/ ?>