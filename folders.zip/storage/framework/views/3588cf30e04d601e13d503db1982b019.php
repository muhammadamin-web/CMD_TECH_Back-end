
<?php $__env->startSection('meta'); ?>
<meta name="keywords" content="люстра в ташкенте, qandillar, свечи, qandillar do'koni, свечной магазин, qandillar narxi, цена на свечи, qandillar xususiyatlari, свечи особенности, qandillar turlari, виды свечей, qandillar qanday ishlatiladi, как использовать свечи, qandillar qanday tozalaydi, как очистить свечи, qandillar va salomatlik, свечи и здоровье, qandillar va madaniyat, свечи и культура, qandillar va san'at, свечи и искусство, qandillar va hayvonlar, свечи и животные, qandillar va yodgorlik, свечи и память, qandillar sotib olish, купить свечи, qandillar hisobi, расчет свечей">
<meta name="description" content="люстра в ташкенте. Bizning qandillar do'konimizda eng yaxshi va sifatli qandillarni topishingiz mumkin. Bizning do'kondan oson va tez yoqtirib olishingiz mumkin">
<meta property="og:title" content="Qandillar - eng yaxshi va sifatli qandillar">
<meta property="og:description" content="Bizning qandillar do'konimizda eng yaxshi va sifatli qandillarni topishingiz mumkin. Bizning do'kondan oson va tez yoqtirib olishingiz mumkin">
<title>Euro Light - <?php echo e(__('app.categories')); ?></title>
<link rel="stylesheet" href="<?php echo e(asset('css/product.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <?php echo e(__('Categories')); ?>

                    <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-sm btn-primary float-right"><?php echo e(__('Create Category')); ?></a>
                </div>

                <div class="card-body">
                    <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                    <?php endif; ?>

                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th><?php echo e(__('Name')); ?></th>
                                <th><?php echo e(__('Actions')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($category->name_uz); ?></td>

                                <td>
                                    <?php if($category->image_path): ?>
                                    <img src="<?php echo e(asset($category->image_path)); ?>" alt="<?php echo e($category->name_uz); ?>" width="50">
                                    <?php endif; ?>
                                </td>
                                <td>
                                <a href="<?php echo e(route('categories.show', $category->id)); ?>" class="btn btn-sm btn-primary">Show</a>
         
   
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div> -->

<div class="products" id="products">


    
    <div class="products_black product_page">
      <h2 class="lang" key="products_category"><?php echo e(__('app.categories')); ?></h2>

      <div class="products_container">
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <a href="<?php echo e(route('category.show', ['locale' => app()->getLocale(), 'slug' => $category->{'slug_' . app()->getLocale()}])); ?>" class="product_card">

          <div class="product_img_wrapper">
            <img class="product_inner-img" src="<?php echo e(asset($category->image_path)); ?>" />
            <div class="product_middle">
              <div class="product_text lang" key="products1"><?php echo e($category->{'name_' . app()->getLocale()}); ?></div>
            </div>
          </div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       

      </div>
    </div>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\developer\real projects\Euro Light\hosting Euro_light\Euro_Light\resources\views/categories/index.blade.php ENDPATH**/ ?>