

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Дизайн интерьера')); ?>

                <a href="<?php echo e(route('interier_designs.create')); ?>" class="btn btn-sm btn-primary float-right"><?php echo e(__('Создать дизайн интерьера')); ?></a>

                </div>
                <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                        <th><?php echo e(__('Название RU')); ?></th>
                <th><?php echo e(__('Название УЗ')); ?></th>
                            <th><?php echo e(__('Изображение')); ?></th>
                            <th><?php echo e(__('Действия')); ?></th>

                            <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $designs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interier_design): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($interier_design->name_uz); ?></td>
                                <td><?php echo e($interier_design->name_uz); ?></td>
                                <td>
                                    <?php if($interier_design->image_path): ?>
                                    <img src="<?php echo e(asset($interier_design->image_path)); ?>" alt="<?php echo e($interier_design->name_uz); ?>" width="50">
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('interier_designs.edit', $interier_design->id)); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Редактировать')); ?></a>
                                    <a href="<?php echo e(route('interier_designs.show', $interier_design->id)); ?>" class="btn btn-sm btn-primary">Показывать</a>
                                    <form method="POST" action="<?php echo e(route('interier_designs.destroy', $interier_design->id)); ?>" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger"><?php echo e(__('Удалить')); ?></button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\developer\real projects\Euro Light\hosting Euro_light\Euro_Light\resources\views/admin/interier_designs/index.blade.php ENDPATH**/ ?>