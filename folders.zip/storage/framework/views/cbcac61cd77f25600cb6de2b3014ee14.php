<?php $__env->startSection('content'); ?>
<div id="home" style="position: absolute; top: -200px;"></div>
<div class="img-slider">
    <!-- Slider navigation buttons -->
    <div class="navigation">
        <div class="slider-btn active"></div>
        <div class="slider-btn"></div>
        <div class="slider-btn"></div>
    </div>

    <div class="slide active">
        <img src="<?php echo e(asset('images/static_img/1.jpg')); ?>" alt="">
    </div>
    <div class="slide">
        <img src="<?php echo e(asset('images/static_img/4.jpg')); ?>" alt="">
    </div>
    <div class="slide">
        <img src="<?php echo e(asset('images/static_img/3.jpg')); ?>" alt="">
    </div>


</div>

<script src="assets/js/scripts.js" type="text/javascript"></script>


<div class="about" id="about">
    <h2 class="title_class lang" key="about"><?php echo e(__('app.about')); ?></h2>
    <div class="container">
        <img src="<?php echo e(asset('images/static_img/about.jpg')); ?>" alt="">
        <h5 class="lang" key="about_text"><?php echo e(__('app.about_text')); ?></h5>
    </div>
</div>



<div class="projects" id="projects">
    <div class="title_project_home" style="width: 100%;">
        <h2 class="title_class lang" key="projects"><?php echo e(__('app.projects')); ?></h2>
    </div>
    <div class="big">
        <?php $counter = 0; ?>
        <?php foreach ($projects as $project) : ?>

            <a href="<?php echo e(route('project.show', ['locale' => app()->getLocale(), 'project' => $project->id])); ?>" class="img-wrapper_container<?= $counter; ?>">
                <div class="img-wrapper">
                    <img class="inner-img" src="<?php echo e(asset($project->image_path)); ?>" />
                    <div class="middle">
                        <div class="text lang" key="projects<?= $counter; ?>"><?php echo e($project->{'name_' . app()->getLocale()}); ?></div>
                        <p class="more lang" key="more"><?php echo e(__('app.more')); ?></p>
                    </div>
                </div>
            </a>

            <?php $counter++; ?>
        <?php endforeach; ?>
    </div>
</div>







<div class="products" id="products">
    <h2 class="title_class lang" key="products_category"><?php echo e(__('app.products_category')); ?></h2>



    <div class="category_container">

        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <a href="<?php echo e(route('category.show', ['locale' => app()->getLocale(), 'category' => $category->id])); ?>" class="product_card">

            <div class="product_img_wrapper">
                <img class="product_inner-img" src="<?php echo e(asset($category->image_path)); ?>" />
                <div class="product_middle">
                    <div class="product_text lang" key="products1"><?php echo e($category->{'name_' . app()->getLocale()}); ?></div>
                </div>
            </div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

    <div class="products_black">


        <div class="product_home_container">
            <h2 class="title_class product_page_title lang" key="products"><?php echo e(__('app.products')); ?></h2>
            <div class="cards_container">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <a href="<?php echo e(route('product.show', ['locale' => app()->getLocale(), 'product' => $product->id])); ?>">
                    <div class="product_page_card">
                        <img src="<?php echo e(asset($product->image_path)); ?>" alt="">

                        <h4 class="product_card_text"><?php echo e($product->{'name_' . app()->getLocale()}); ?></h4>
                    </div>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
        <a href="<?php echo e(route('product',[app()->getLocale()])); ?>" class="product_more"><?php echo e(__('app.more')); ?> ...</a>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\developer\real projects\hosting Euro_light\Euro_Light\resources\views/home.blade.php ENDPATH**/ ?>