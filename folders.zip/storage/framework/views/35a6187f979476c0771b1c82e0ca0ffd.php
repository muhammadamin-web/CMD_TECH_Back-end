<footer>
    <div class="footer_container">
      <div class="contact" id="contact">
        <div class="title_footer lang" key="contact"><?php echo e(__('app.contact')); ?></div>
        <div class="phone_container">
          <i class="fa fa-phone"></i>
          <div class="phones">
            <a href="tel:+998998968885">+998 99 896 88 85</a>
          </div>
        </div>
        <div class="mail_container">
          <i class="fa fa-envelope"></i>
          <div class="mail">
            <a href="https://my.mail.ru/ok/565099328976/">Zubayir@mail.ru</a>
          </div>
        </div>
      </div>
      <div class="time_location">
        <div class="title_footer lang" key="job_time_title"><?php echo e(__('app.job_time_title')); ?></div>

        <div class="time_container">
          <i class="fa fa-clock-o"></i>
          <div class="time">
            <p class="lang" key="job_time"><?php echo e(__('app.job_time')); ?></p>
          </div>
        </div>
        <!-- Каждый день
        с 10:00 до 22:00 -->
        <div class="location_container">
          <i class="fa fa-map-marker"></i>
          <div class="location">
            <p class="lang" key="location"><?php echo e(__('app.location')); ?></p>
          </div>
        </div>


      </div>
      <div class="social_netvork">
        <div class="title_footer lang" key="social_title"><?php echo e(__('app.social_title')); ?></div>

        <div class="telegram_container">
          <i class="fa fa-telegram"></i>
          <div class="telegram">
            <a href="https://t.me/euro_light">@Euro_light</a>
          </div>
        </div>
        <div class="instagram_container">
          <i class="fa fa-instagram"></i>
          <div class="instagram">
            <a href="https://www.instagram.com/lyustra_eurolight/">@lyustra_euroligth</a>
          </div>
        </div>
      </div>
    </div>


  </footer>
  <div class="powered_by">
    <div class="powered_by_text">
      <P class="lang" >© 2023 Powered by </P><a href=""> CMD TECH</a>
    </div>
  </div><?php /**PATH D:\personal\developer\real projects\hosting Euro_light\Euro_Light\resources\views/layouts/footer.blade.php ENDPATH**/ ?>