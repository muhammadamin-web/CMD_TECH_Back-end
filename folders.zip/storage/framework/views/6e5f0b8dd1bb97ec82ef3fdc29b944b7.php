

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <?php echo e(__('Категории')); ?>

                    <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-sm btn-primary float-right"><?php echo e(__('Создать категорию')); ?></a>
                </div>

                <div class="card-body">
                    <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                    <?php endif; ?>

                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th><?php echo e(__('Имя')); ?></th>
                                <th><?php echo e(__('Изображение')); ?></th>
                                <th><?php echo e(__('Действия')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($category->name_uz); ?></td>
                                <td>
                                    <?php if($category->image_path): ?>
                                    <img src="<?php echo e(asset($category->image_path)); ?>" alt="<?php echo e($category->name_uz); ?>" width="50">
                                    <?php endif; ?>
                                </td>
                                <td>
                                <a href="<?php echo e(route('categories.show', $category->id)); ?>" class="btn btn-sm btn-primary">Показывать</a>
                                    <a href="<?php echo e(route('categories.edit', $category->id)); ?>" class="btn btn-sm btn-primary"><?php echo e(__('Редактировать')); ?></a>
                                    <form method="POST" action="<?php echo e(route('categories.destroy', $category->id)); ?>" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger"><?php echo e(__('Удалить')); ?></button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\developer\real projects\Euro Light\hosting Euro_light\Euro_Light\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>