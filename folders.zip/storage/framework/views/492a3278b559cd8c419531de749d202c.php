<nav id="navbar">
    <div class="menu">
        <input type="checkbox" id="check">
        <div class="logo"><a href="<?php echo e(route('home',[app()->getLocale()])); ?>">
        <img src="<?php echo e(asset('images/static_img/photo_2023-11-22_17-49-31.png')); ?>" alt="" class="img_logo1">

            </a></div>
        <ul>
        <label class="btn cancel"><i class="fa fa-close"></i></label>
            <li><a href="<?php echo e(route('home',[app()->getLocale()])); ?>" class="lang" key="home" for="check"><?php echo e(__('app.home')); ?></a></li>
            <li><a href="<?php echo e(route('home',[app()->getLocale()])); ?>#about" class="lang" key="about"><?php echo e(__('app.about')); ?></a></li>
            <li><a href="<?php echo e(route('project',[app()->getLocale()])); ?>" class="lang" key="projects"><?php echo e(__('app.projects')); ?></a></li>
            <li><a href="<?php echo e(route('interier_design',[app()->getLocale()])); ?>" class="lang" key="projects"><?php echo e(__('app.interier_design')); ?></a></li>
            <li><a href="<?php echo e(route('lyustra_v_tashkente',[app()->getLocale()])); ?>" class="lang " for="check" key="contact"><?php echo e(__('app.contact')); ?></a></li>
            <li><a href="<?php echo e(route('category',[app()->getLocale()])); ?>" class="lang" key="products"><?php echo e(__('app.products')); ?></a></li>
            <div class="language_container">
                <?php $__currentLoopData = config('app.available_locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($locale === app()->getLocale()): ?>
                <a class="lang-button active_lang" onclick="switchLocale('<?php echo e($locale); ?>')" style="<?php echo e($index === 0 ? 'border-right: 1px solid white;' : ''); ?>"><?php echo e(strtoupper($locale)); ?></a>
                <?php else: ?>
                <a class="lang-button" onclick="switchLocale('<?php echo e($locale); ?>')" style="<?php echo e($index === 0 ? 'border-right: 1px solid white;' : ''); ?>"><?php echo e(strtoupper($locale)); ?></a>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </ul>
        <label for="check" class="btn bars"><i class="fa fa-bars"></i></label>
    </div>
</nav><?php /**PATH D:\personal\developer\real projects\Euro Light\hosting Euro_light\Euro_Light\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>