<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Crud_one;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class Crud_oneController extends Controller
{
    public function index()
    {
        $modelName = config('app.crud_one_model');
        $model = app("App\\Models\\" . $modelName);
        $crud_ones = $model::all();
    
        return view('admin.crud_ones.index', compact('crud_ones'));
    }

    public function create()
    {
        return view('admin.crud_ones.create');
    }

    public function store(Request $request)
    {
        $locales = config('app.available_locales', ['ru', 'uz', 'en']);
        $rules = $this->buildValidationRules($locales);
        $validatedData = $request->validate($rules);

        $imageName = $this->handleImageUpload($request);
        $createData = $this->buildDataArray($validatedData, $locales, $imageName);

        Crud_one::create($createData);
        return redirect()->route(config('app.crud_one_admin') . '.index')->with('success', 'Design created successfully.');
    }

    public function show($id)
    {
        $modelName = config('app.crud_one_model');
        $crud_one = app("App\\Models\\" . $modelName)::findOrFail($id);
        return view('admin.crud_ones.show', compact('crud_one'));
    }

    public function edit($id)
    {
        $modelName = config('app.crud_one_model');
        $crud_one = app('App\\Models\\' . $modelName)::findOrFail($id);
        return view('admin.crud_ones.edit', compact('crud_one'));
    }

    public function update(Request $request, $id)
    {
        $modelName = config('app.crud_one_model');
        $crud_one = app("App\\Models\\" . $modelName)::findOrFail($id);
    
        $locales = config('app.available_locales', ['ru', 'uz', 'en']);
        $rules = $this->buildValidationRules($locales);
        $validatedData = $request->validate($rules);

        $imageName = $this->handleImageUpload($request, $crud_one);
        $updateData = $this->buildDataArray($validatedData, $locales, $imageName);

        $crud_one->update($updateData);
        return redirect()->route(config('app.crud_one_admin') . '.index')->with('success', 'Design updated successfully.');
    }

    public function destroy($id)
    {
        $modelName = config('app.crud_one_model');
        $crud_one = app("App\\Models\\" . $modelName)::findOrFail($id);
    
        if ($crud_one->image_name) {
            $imagePath = public_path('images/crud_ones/' . $crud_one->image_name);
            if (file_exists($imagePath)) {
                unlink($imagePath);
            }
        }
    
        $crud_one->delete();
        return redirect()->route(config('app.crud_one_admin') . '.index')->with('success', 'Design deleted successfully.');
    }

    private function buildValidationRules($locales)
    {
        $rules = ['image_path' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048'];
        foreach ($locales as $locale) {
            $rules["name_$locale"] = 'required|string|max:255';
            $rules["description_$locale"] = 'required|string';
            $rules["tags_$locale"] = 'nullable|string';
            $rules["meta_description_$locale"] = 'nullable|string';
        }
        return $rules;
    }

    private function handleImageUpload($request, $existingModel = null)
    {
        if ($request->hasFile('image_path')) {
            if ($existingModel && $existingModel->image_name) {
                $this->deleteExistingImage($existingModel->image_name);
            }
            $imageName = time() . '.' . $request->image_path->extension();
            $request->image_path->move(public_path('images/crud_ones'), $imageName);
            return $imageName;
        }
        return $existingModel ? $existingModel->image_name : null;
    }

    private function deleteExistingImage($imageName)
    {
        $imagePath = public_path('images/crud_ones/' . $imageName);
        if (file_exists($imagePath)) {
            unlink($imagePath);
        }
    }

    private function buildDataArray($validatedData, $locales, $imageName)
    {
        $data = [];
        foreach ($locales as $locale) {
            $data["name_$locale"] = $validatedData["name_$locale"];
            $data["description_$locale"] = $validatedData["description_$locale"];
            $data["tags_$locale"] = $validatedData["tags_$locale"];
            $data["meta_description_$locale"] = $validatedData["meta_description_$locale"];
            $data["slug_$locale"] = Str::slug($validatedData["name_$locale"]);
        }
        $data['image_path'] = $imageName ? 'images/crud_ones/' . $imageName : null;
        $data['image_name'] = $imageName;
        return $data;
    }
}
