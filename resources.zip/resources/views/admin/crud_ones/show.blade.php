@extends('admin.layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ config('app.admin_crud_name') }}</div>

                <div class="card-body">
                    @foreach (config('app.available_locales', ['ru', 'en', 'en']) as $locale)
                        <!-- Name -->
                        <div class="form-group">
                            <h5>{{ __('Название') }} ({{ $locale }})</h5>
                            <p>{{ $crud_one->{'name_' . $locale} }}</p>
                        </div>

                        <!-- Description -->
                        <div class="form-group">
                            <h5>{{ __('Описание') }} ({{ $locale }})</h5>
                            <p>{!! $crud_one->{'description_' . $locale} !!}</p>
                        </div>

                        <!-- Tags -->
                        <div class="form-group">
                            <h5>{{ __('Теги') }} ({{ $locale }})</h5>
                            <p>{{ $crud_one->{'tags_' . $locale} }}</p>
                        </div>
                    @endforeach

                    <!-- Image -->
                    @if($crud_one->image_path)
                        <div class="form-group">
                            <h5>{{ __('Изображение') }}</h5>
                            <div>
                                <img src="{{ asset($crud_one->image_path) }}" alt="{{ $crud_one->name_ru }}" class="img-fluid">
                            </div>
                        </div>
                    @endif

                    <a href="{{ route(config('app.crud_one_admin') . '.index') }}" class="btn btn-secondary">{{ __('Назад к списку') }}</a>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
