@extends('admin.layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <h2 class="mb-4">Создать {{ config('app.admin_crud_text') }}</h2>

            <form method="POST" action="{{ route(config('app.crud_one_admin') . '.store') }}" enctype="multipart/form-data">
                @csrf

                @foreach (config('app.available_locales') as $locale)
                    <!-- Name -->
                    <div class="form-group">
                        <h5 for="name_{{ $locale }}">{{ __('Название') }} ({{ $locale }})</h5>
                        <input id="name_{{ $locale }}" type="text" class="form-control @error('name_' . $locale) is-invalid @enderror" name="name_{{ $locale }}" value="{{ old('name_' . $locale) }}" required autocomplete="name_{{ $locale }}" autofocus>
                        @error('name_' . $locale)
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                        @enderror
                    </div>

                    <!-- Description -->
                    <div class="form-group">
                        <h5 for="description_{{ $locale }}">{{ __('Описание') }} ({{ $locale }})</h5>
                        <textarea id="description_{{ $locale }}" class="form-control @error('description_' . $locale) is-invalid @enderror"value="{{ old('name_' . $locale) }}" name="description_{{ $locale }}">{{ old('description_' . $locale) }}</textarea>
                        @error('description_' . $locale)
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                        @enderror
                    </div>

                    <!-- Meta Description -->
                    <div class="form-group">
                        <h5 for="meta_description_{{ $locale }}">{{ __('Мета описание') }} ({{ $locale }})</h5>
                        <textarea id="meta_description_{{ $locale }}" class="form-control @error('meta_description_' . $locale) is-invalid @enderror" name="meta_description_{{ $locale }}" required>{{ old('meta_description_' . $locale) }}</textarea>
                        @error('meta_description_' . $locale)
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                        @enderror
                    </div>

                    <!-- Tags -->
                    <div class="form-group">
                        <h5 for="tags_{{ $locale }}">{{ __('Теги') }} ({{ $locale }})</h5>
                        <input id="tags_{{ $locale }}" type="text" class="form-control @error('tags_' . $locale) is-invalid @enderror" name="tags_{{ $locale }}" value="{{ old('tags_' . $locale) }}">
                        @error('tags_' . $locale)
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                        @enderror
                    </div>
                @endforeach

                <!-- Image Upload -->
                <div class="form-group">
                    <h5 for="image_path">{{ __('Изображение') }}</h5>
                    <input id="image_path" type="file" class="form-control-file @error('image_path') is-invalid @enderror" name="image_path" accept="image/*">
                    @error('image_path')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                    @enderror
                </div>

                <!-- Submit Button -->
                <div class="form-group mb-0">
                    <button type="submit" class="btn btn-primary">
                        {{ __('Создать') }}
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
