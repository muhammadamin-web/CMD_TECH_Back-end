@extends('admin.layouts.app')

@section('content')
<div class="container">
    <h2>{{ __('Список Комментарий клиента') }}</h2>
    <a href="{{ route('client_comments.create') }}" class="btn btn-primary" style="float: right; margin-bottom:20px;">{{ __('Создать Комментарий клиента') }}</a>
    <table class="table table-striped mt-3">
        <thead>
            <tr>
                <th>{{ __('Название RU') }}</th>
                <th>{{ __('Название УЗ') }}</th>
                <th>img</th>
                <th>{{ __('Действия') }}</th>
            </tr>
        </thead>
        <tbody>
            @foreach($client_comments as $client_comment)
            <tr>
                <td>{{ $client_comment->name_ru }}</td>
                <td>{{ $client_comment->name_ru }}</td>
                <td> <img src="{{ asset($client_comment->image_path) }}" alt="{{ $client_comment->image_name }}" class="img-fluid" width="50"></td>
                <td>
                    <a href="{{ route('client_comments.show', $client_comment) }}" class="btn btn-sm btn-info">{{ __('Показывать') }}</a>
                    <a href="{{ route('client_comments.edit', $client_comment) }}" class="btn btn-sm btn-warning">{{ __('Редактировать') }}</a>
                    <form action="{{ route('client_comments.destroy', $client_comment) }}" method="POST" style="display:inline;">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-sm btn-danger">{{ __('Удалить') }}</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
