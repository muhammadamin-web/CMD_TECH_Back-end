@extends('admin.layouts.app')

@section('content')

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Туры') }}
                <a href="{{ route('tours.create') }}" class="btn btn-sm btn-primary float-right">{{ __('Создать туры') }}</a>

                </div>
                <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th>{{ __('Имя') }}</th>
                            <th>{{ __('Категория') }}</th>
                            <th>{{ __('Изображение') }}</th>
                            <th>{{ __('Действия') }}</th>

                            <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($tours as $tour)
                            <tr>
                                <td>{{ $tour->name_ru }}</td>
                                <td>{{ $tour->category->name_ru }}</td>
                                <td style="">
                                @foreach(json_decode($tour->images) as $image)
                    <img src="{{ asset($image) }}" alt="{{ $tour->name_ru }}" class="img-fluid" width="50" style="margin: 3px;">
                    @endforeach
                                </td>
                                <td>
                                    <a href="{{ route('tours.edit', $tour->id) }}" class="btn btn-sm btn-primary">{{ __('Редактировать') }}</a>
                                    <a href="{{ route('tours.show', $tour->id) }}" class="btn btn-sm btn-primary">Показывать</a>
                                    <form method="POST" action="{{ route('tours.destroy', $tour->id) }}" style="display:inline;">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-sm btn-danger">{{ __('Удалить') }}</button>
                                    </form>
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
