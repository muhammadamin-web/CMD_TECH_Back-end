@extends('layouts.app')
@section('meta')

<title>{{ config('app.site_title') }} </title>

<meta name="description" content="Tourfetto - ваш путеводитель в мир международных путешествий. Откройте удивительные туры по всему миру.">
<meta name="keywords" content="международное туристическое агентство, мировые туры, путешествия, Tourfetto">
<meta property="og:title" content="Tourfetto - Международное туристическое агентство, Туры по всему миру">
<meta property="og:description" content="Tourfetto - ваш путеводитель в мир международных путешествий. Откройте удивительные туры по всему миру.">
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:title" content="Tourfetto - Международное туристическое агентство, Туры по всему миру">
<meta property="twitter:description" content="Tourfetto - ваш путеводитель в мир международных путешествий. Откройте удивительные туры по всему миру.">
<meta property="twitter:image" content="URL_изображения_тура_или_агентства_Tourfetto">
<!-- Qo'shimcha SEO va sayt optimallashtirish uchun taglar -->
<link rel="apple-touch-icon" sizes="76x76" href="{{ asset('images/static_img/icon.png') }}">
<link rel="manifest" href="/path/to/your/site.webmanifest">
<link rel="mask-icon" href="{{ asset('images/static_img/icon.svg') }}" color="#5bbad5">
<link rel="shortcut icon" href="{{ asset('images/static_img/icon.ico') }}">
<!-- Qo'shimcha uslublar va scriptlar -->
<!-- Qo'shimcha uslublar va scriptlar -->
<link rel="stylesheet" href="{{ asset('css/product.css') }}">
<script src="{{ asset('js/scripts.js') }}" defer></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/freeps2/a7rarpress@main/swiper-bundle.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
@endsection
@section('navbar')
<nav class="nav">
    <div class="container">
        <div class="menu ">
            <input type="checkbox" id="check">

            <a href="{{ route('home',[app()->getLocale()]) }}">
                <div class="logo">
                    <img class="" data-original="{{ asset('images/static_img/logo1.1.png') }}" id="logo_img" src="{{ asset('images/static_img/logo1.1.png') }}" data-scroll-src="{{ asset('images/static_img/logo2.2.png') }}" alt="Logo" /> <!-- <img src="assets/images/logo1.1.png" alt=""> -->
            </a>
        </div>


        <ul class="nav_list">
            <label class="btnn cancel close_btn">
                <i class="fa fa-close" style="color: white;"></i>
            </label>
            <li>
                <a href="{{ route('home',[app()->getLocale()]) }}" class="lang">{{ __('app.home') }}</a>
            </li>
            <li>
                <a href="{{ route('home',[app()->getLocale()]) }}#about" class="lang">{{ __('app.about') }}</a>
            </li>
            <li>
                <a href="{{ route('news',[app()->getLocale()]) }}" class="lang">{{ __('app.new') }}</a>
            </li>
            <li>
                <a href="{{ route('category',[app()->getLocale()]) }}" class="lang">{{ __('app.tour') }}</a>
            </li>
            <li>
                <a href="{{ route('tour',[app()->getLocale()]) }}" class="lang">{{ __('app.tour1') }}</a>
            </li>
            <li>
                <a href="#contact" class="lang">{{ __('app.contact') }}</a>
            </li>
            <div class="language_container1">
                @foreach (config('app.available_locales') as $locale)
                <a class="lang-button {{ app()->getLocale() === $locale ? 'active_lang' : '' }}" onclick="switchLocale('{{ $locale }}')" >
                    <img src="{{ asset('images/static_img/flag_' . $locale . '.png') }}" alt="{{ $locale }}">
                </a>
                @endforeach
            </div>

        </ul>
        <a href="tel:+998972680088" class="nav_tel">+998 97 268-00-88</a>
        <label class="btnn bars menu1 open_btn" style=" float: right; color: #174581;" for="check">
            <i class="fa fa-bars"></i>
        </label>
    </div>
    </div>
</nav>



@endsection

@section('content')

<div class="home-carousel-wrapper">
    <div class="home-carousel">
        <div class="home-carousel-panel">
            <div class="home-carousel-image" style="background-image: url('{{ asset('images/static_img/img_slider1.jpg') }}')"></div>
            <div class="home-carousel-image" style="background-image: url('{{ asset('images/static_img/img_slider1.jpg') }}')"></div>
            <div class="home-carousel-image" style="background-image: url('{{ asset('images/static_img/img_slider1.jpg') }}')"></div>
        </div>
        <div class="home-carousel-panel">
            <div class="home-carousel-image" style="background-image: url('{{ asset('images/static_img/img_slider2.jpg') }}')"></div>
            <div class="home-carousel-image" style="background-image: url('{{ asset('images/static_img/img_slider2.jpg') }}')"></div>
            <div class="home-carousel-image" style="background-image: url('{{ asset('images/static_img/img_slider2.jpg') }}')"></div>
        </div>
        <div class="home-carousel-panel">
            <div class="home-carousel-image" style="background-image: url('{{ asset('images/static_img/img_slider3.jpg') }}')"></div>
            <div class="home-carousel-image" style="background-image: url('{{ asset('images/static_img/img_slider3.jpg') }}')"></div>
            <div class="home-carousel-image" style="background-image: url('{{ asset('images/static_img/img_slider3.jpg') }}')"></div>
        </div>

    </div>
</div>
<div class="home-carousel-text">
    <div class="text-dynamic">
        <div class="text-dynamic-content-1 home-carousel-rotate-wrapper">
            <div class="text-dynamic-content home-carousel-rotate-item lang">{{ __('app.img_slider1') }}</div>
            <div class="text-dynamic-content home-carousel-rotate-item lang">{{ __('app.img_slider1') }}</div>
            <div class="text-dynamic-content home-carousel-rotate-item lang">{{ __('app.img_slider1') }}</div>
        </div>
        <div class="text-dynamic-content-2 home-carousel-rotate-wrapper" data-delay="200">
            <div class="text-dynamic-content home-carousel-rotate-item lang">{{ __('app.img_slider2') }}</div>
            <div class="text-dynamic-content home-carousel-rotate-item lang">{{ __('app.img_slider2') }}</div>
            <div class="text-dynamic-content home-carousel-rotate-item lang">{{ __('app.img_slider2') }}</div>
        </div>
    </div>
</div>
</div>
<section class="about" id="about">
    <div class="container">
        <div class="about_box">
            <div class="about_card_vidio" onclick="openNav('myModal', 'myVideo5')">
                <i class="fas fa-play-circle " id="myBtn"></i>
                <img src="{{ asset('images/static_img/img_slider2.jpg') }}" alt="" />
            </div>
            <div class="about_card_text">
                <div class="about_title1 ">
                    <h2 class="about_title lang">{{ __('app.about_text1') }}</h2>
                    <p class="about_title lang" style="color: #FDBA24;">{{ __('app.about_text2') }}</p>
                </div>
                <p class="about_text lang">{{ __('app.about_text3') }}</p>
                <p class="about_text lang">{{ __('app.about_text4') }}</p>
            </div>
        </div>
    </div>
    <div id="myModal" class="modal">
        <div class="modal-content" onclick="closeNav('myModal', 'myVideo5')">
            <div class="video-container">
                <span class="close">&times;</span>
                <video class="about_vidio" id="myVideo5" controls>
                    <source src="{{ asset('images/static_img/abut_vidio.mp4') }}" type="video/mp4">
                </video>
            </div>
        </div>
    </div>
</section>
<section class="destination">
    <div class="container">
        <h2 class="container_title lang">{{ __('app.destination_text1') }}</h2>
        <div class="destination_box">
            <div class="destination_card_img1">

                @foreach($tours as $tour)
                @php
                $containerNumber = $loop->iteration === 1 || ($loop->iteration - 1) % 5 === 0 ? 1 : 2;
                $images = json_decode($tour->images, true); // Rasmlar massivi
                @endphp

                <a href="{{ route('tour.show',['locale' => app()->getLocale(), 'slug' => $tour->{'slug_' . app()->getLocale()}] ) }}" class="img_wrapper_container{{ $containerNumber }}">
                    <div class="img_wrapper">
                        <div class="img_text1">
                            <p class="lang">{{ Str::limit($tour->{'name_' . app()->getLocale()}, 20) }}</p>
                            <div class="border"></div>
                        </div>
                        @if(!empty($images) && isset($images[0])) {{-- Birinchi rasm mavjudligini tekshirish --}}
                        <img src="{{ asset($images[0]) }}" alt="{{ $tour->{'name_' . app()->getLocale()} }}" />
                        @endif
                    </div>
                </a>
                @endforeach





            </div>
        </div>
    </div>
</section>
<section class="seasonal">
    <div class="container">
        <h2 class="container_title lang">{{ __('app.seasonal_text1') }}</h2>
        <div class="seasonal_box">
            @foreach($categories as $category)

            <div class="seasonal_card">
                <a class="seasonal_img_link" href="{{ route('category.show', ['locale' => app()->getLocale(), 'slug' => $category->{'slug_' . app()->getLocale()}]) }}">
                    <img src="{{ asset($category->image_path) }}" alt="" />
                    <div class="card_overlay">
                        <p class="card_text lang">{{ Str::limit($category->{'name_' . app()->getLocale()}, 20) }}
</p>
                        <a class="card_text2 lang" href="{{ route('category.show', ['locale' => app()->getLocale(), 'slug' => $category->{'slug_' . app()->getLocale()}]) }}">{{ __('app.seasonal_text5') }}</a>
                    </div>
                </a>
            </div>
            @endforeach


        </div>
    </div>
</section>
<div class="slider">
    <h2 class="container_title lang">{{ __('app.aboutme_text1') }}</h2>
    <div class="slide-container swiper">
        <div class="slide-content">
            <div class="card-wrapper swiper-wrapper">
                @foreach($client_comments as $client_comment)

                <div class="card swiper-slide">
                    <div class="image-content">
                        <span class="overlay"></span>
                        <div class="card-image">
                            <img src="{{ asset($client_comment->image_path) }}" alt="" class="card-img" />
                        </div>
                    </div>
                    <div class="card-content">
                        <h2 class="name">{{ Str::limit($client_comment->{'name_' . app()->getLocale()}, 30) }}</h2>
                        <p class="description">{{ Str::limit($client_comment->{'description_' . app()->getLocale()}, 100) }}</p>

                    </div>
                </div>
                @endforeach

            </div>
            <!-- <div class="swiper-button-next swiper-navBtn"></div> -->
            <!-- <div class="swiper-button-prev swiper-navBtn"></div> -->
            <div class="swiper-pagination"></div>
        </div>
    </div>
</div>
<section class="new_container" id="news">
    <div class="container">
        <h2 class="container_title lang">{{ __('app.new') }}</h2>
        <div class="new_box">
            @foreach($crud_one as $news)

            <a href="{{ route('news.show', ['locale' => app()->getLocale(), 'slug' => $news->{'slug_' . app()->getLocale()}]) }}" class="new_link ">
                <div class="new_card ">
                    <img class="new_card_img" src="{{ asset($news->image_path) }}" alt="" />
                    <div class="new_card_text1">
                        <div class="text_row1">
                            <h2>{{ Str::limit($news->{'name_' . app()->getLocale()}, 20) }}</h2>
                            <!-- <h4>Tailand Qirolligi</h4> -->
                        </div>
                        <div class="text_row2">
                            <a class="row2_link" href="tel:+998972680088">+998(97)268-00-88</a>
                        </div>
                    </div>
                    <h2 class="new_subtitle1">{{ Str::limit($news->{'name_' . app()->getLocale()}, 20) }}</h2>
                    <p class="new_subtitle2">{{ Str::limit($news->{'meta_description_' . app()->getLocale()}, 50) }}</p>
                    <div class="new_card_text2">
                        <a href="{{ route('news.show', ['locale' => app()->getLocale(), 'slug' => $news->{'slug_' . app()->getLocale()}]) }}">{{ __('app.more') }}</a>
                        <div class="new_card_icon">
                            <img class="" src="{{ asset('images/static_img/calendar-249.png') }}" alt="" />
                            <p class="news_card_date">{{ $news->created_at_formatted }}</p> <!-- Bu yerda o'zgarish qilindi -->
                        </div>
                    </div>
                </div>
            </a>
            @endforeach

        </div>
        <div class="slider_btn_box">
            <button class="slider-btn prev-btn">&#10094;</button>
            <button class="slider-btn next-btn">&#10095;</button>
        </div>
</section>
<section class="order">
    <div class="container">
        <p class="order_subtitle lang">{{ __('app.order_text1') }}</p>
        <h2 class="order_title lang">{{ __('app.order_text2') }}</h2>
        <div class="order_box">
            <form action="{{ route('home.lead', ['locale' => app()->getLocale()]) }}" method="POST" id="leadForm">
                @csrf <!-- CSRF token -->

                <input class="order_input" type="text" placeholder="ИМЯ" id="name" name="name" required>
                <input class="order_input" type="text" placeholder="+998_______" id="phone" name="phone" required>
                <input class="order_input" type="email" placeholder="yourmail@gmail.com" id="email" name="email" required>
                <textarea class="coment_input" type="text" id="description" name="description"></textarea>
                <button type="submit" class="btn order_link btn-primary" style="">{{ __('app.order_text3') }}</button>
            </form>
            <!-- <a class="order_link lang" id="myBtnn" href="#!"></a> -->
        </div>
    </div>
</section>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var form = document.getElementById('leadForm');

        form.addEventListener('submit', function(e) {
            e.preventDefault();

            var formData = new FormData(this);
            fetch("{{ route('home.lead', ['locale' => app()->getLocale()]) }}", {
                    method: 'POST',
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                    },
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.message) {
                        var modal = document.getElementById('myModal_2');
                        modal.classList.add('show');

                        setTimeout(function() {
                            modal.classList.remove('show');
                            modal.classList.add('hide');
                        }, 1500);

                        // Formani tozalash
                        form.reset();
                    }
                })
                .catch(error => console.error('Xatolik:', error));
        });
    });
</script>
<div id="myModal_2" class="modal2">
    <div class="modal2-content">
        <h1 class="lang" key="">{{ __('app.modal-text') }}</h1>
    </div>
</div>
<div class="modal fade" id="successModal" tabindex="-1" role="dialog" aria-labelledby="successModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <!-- Modal tarkibi -->

            <h1>Murojaat jo'natildi</h1>
        </div>
    </div>
</div>
@endsection