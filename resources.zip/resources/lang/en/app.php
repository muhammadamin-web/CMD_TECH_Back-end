
<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Application Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the application.
    |
    */

    "home" => "Main page",
      "about" => "about Us",
      "new" => "News",
      "tour" => "Category",
      "tour1" => "Tour",

      "contact" => "Contact",
      "img_slider1" => "with us",
      "img_slider2" => "have a nice trip",
      "about_text1" => "TOURFETTO",
      "about_text2" => "About",
      "about_text3" => "Are you taking a well-deserved vacation and want to make the most of it? Our travel agency in Tashkent will help you organize any type of vacation: from an eventful and sports-filled weekend to a long beach vacation. We plan your trip based on your budget and personal needs.",
      "about_text4" => "Employees of our travel agency in Tashkent have a lot of experience, so they provide quick and quality service to customers and provide competent assistance in choosing a tour. We cooperate with the best hotels and tourist organizations in different countries of the world. Traveling with us is easy, pleasant and affordable!",
      "destination_text1" => "Popular Destinations",
      "destination_text2" => "Georgia",
      "destination_text3" => "Georgia",
      "destination_text4" => "Georgia",
      "destination_text5" => "Sharm El Sheikh",
      "destination_text6" => "Vietnam",
      "destination_text7" => "Vietnam",
      "seasonal_text1" => "Seasonal trips",
      "seasonal_text2" => "Turkey",
      "seasonal_text3" => "Georgia",
      "seasonal_text4" => "It's hot",
      "seasonal_text5" => "More ->",
      "aboutme_text1" => "What do they say about us?",
      "order_text1" => "Fill in this field to contact us.",
      "order_text2" => "Order",
      "order_text3" => "send a message",
      "footer_text1" => "Tourism since 2023, TOURFETTO travel agency presented on the international market.",
      "footer_text2" => "Tashkent city",
      "footer_text3" => "Menu",
      "footer_text4" => "Homepage",
      "footer_text5" => "about Us",
      "footer_text6" => "News",
      "footer_text7" => "Category",
      "footer_text8" => "Contact",
      "footer_text9" => "Famous cities",
      "footer_text10" => "Thailand",
      "footer_text11" => "Dubai",
      "footer_text12" => "Turkey",
      "footer_text13" => "Sweden",
      "footer_text14" => "Georgia",
      "footer_text15" => "Vietnam",
      "footer_text16" => "We are on social media",
      "modal-text" => "Your request has been sent successfully✅",

      "intro_text1" => "Tour section",
      "intro_text2" => "Homepage",
      "intro_text3" => "Our tours department",
      "tour_lang1" => "Description",
      "tour_lang2" => "Such trips give tourists the opportunity to gain a deeper understanding of the culture and lifestyle of people living in different parts of the world. Such experiences lead people to witness the rich history and diverse cultures of other countries up close. Tourists usually visit places of historical value, including ancient monuments, museums and art galleries. Here they see local artworks and historical monuments and learn about their history and significance.",
      "tour_lang3" => "Travel undoubtedly gives people the opportunity to see the world and understand new cultures. While traveling, a person discovers new places, learns different cultures and traditions, which enriches his worldview. Traveling also provides an opportunity to make new friends and interact with different people, which expands social networks and strengthens interpersonal relationships. Such adventures increase everyone's life experience, teach new skills and knowledge.",
      "tour_lang4" => "Georgia",
      "tour_lang5" => "Why you should choose TOURFETTO",
      "tour_lang6" => "Best price guarantee with no hidden fees",
      "tour_lang7" => "24/7 customer support",
      "tour_lang8" => "Honest rating of the owners",
      "tour_lang9" => "Only reviews and ratings from real guests",
      "tour_lang10" =>"price: ",
      "tour_lang11" => "Other tours",

      "intro_text4" => "The innovator in us",
      "intro_text6" => "News section",
      "news_text1" => "10 days in Thailand",
      "news_text2" => "seeks to create experiences. Therefore, we are pleased to present you with new and amazing travel packages in Spain, Italy and Greece. This brief description will help you get an idea of ​​what our tours in these beautiful countries will be like.",
      "news_text3" => "Spain: Spain is known for its rich history, colorful culture and stunning architecture. Here you will find old towns, ancient castles and modern works of art. Sights such as Barcelona's Gaudi architecture and Madrid's historic centers await you. You will also be amazed by flamenco dances and delicious Spanish food.",
      "news_text4" => "News",
      "news_text5" => "New tour",

      "intro_text7" => "All our tours department",
      "all_tour_text" => "Popular Destinations",

      "intro_text8" => "News section",
      "intro_text9" => "All categories",

      "more" => "More",
      "" => "",
      "" => "",
      "" => "",
      "" => "",
      "" => "",
      "" => "",
      "" => "",
      "" => "",  
];
