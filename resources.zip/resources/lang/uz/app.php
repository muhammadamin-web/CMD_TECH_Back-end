
<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Application Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the application.
    |
    */

    "home" => "Bosh Sahifa",
      "about" => "Biz haqimizda",
      "new" => "Yangiliklar",
      "tour" => "Kategoriyalar",
      "tour1" => "Sayohat",

      "contact" => "Kontakt",
      "img_slider1" => "Biz bilan",
      "img_slider2" => "maroqli sayohat",
      "about_text1" => "TOURFETTO",
      "about_text2" => "Haqida",
      "about_text3" => "Siz munosib ta'tilga chiqyapsizmi va undan unumli foydalanmoqchimisiz? Toshkentdagi sayyohlik agentligimiz har qanday turdagi dam olishni tashkil etishda yordam beradi, voqealarga boy va sportga boy dam olish kunlaridan tortib to plyajdagi uzoq dam olishgacha. Biz sizning byudjetingiz va shaxsiy ehtiyojlaringizni hisobga olgan holda sayohatingizni rejalashtiramiz.",
      "about_text4" => "Toshkentdagi sayyohlik agentligimiz xodimlari katta tajribaga ega, shuning uchun ular mijozlarga tez va sifatli xizmat ko'rsatadilar va tur tanlashda malakali yordam ko'rsatadilar. Biz dunyoning turli mamlakatlaridagi eng yaxshi mehmonxonalar va sayyohlik tashkilotlari bilan hamkorlik qilamiz. Biz bilan sayohat qilish oson, yoqimli va arzon!",
      "destination_text1" => "Mashhur Yo'nalishlar",
      "destination_text2" => "Gruziya",
      "destination_text3" => "Gruziya",
      "destination_text4" => "Gruziya",
      "destination_text5" => "Sharm el Sheyx",
      "destination_text6" => "Vetnam",
      "destination_text7" => "Vetnam",
      "seasonal_text1" => "Mavsumiy sayohatlar",
      "seasonal_text2" => "Turkiya",
      "seasonal_text3" => "Gruziya",
      "seasonal_text4" => "Issiq-ko'l",
      "seasonal_text5" => "Batafsil ->",
      "aboutme_text1" => "Ular biz haqimizda nima deyishadi?",
      "order_text1" => "Biz bilan bog'lanish uchun ushbu maydonni to'ldiring.",
      "order_text2" => "Buyurtma",
      "order_text3" => "xabar yubormoq",
      "footer_text1" => "TOURFETTO sayyohlik agentligi xalqaro bozorda taqdim etilgan 2023 yildan turizm.",
      "footer_text2" => "Toshkent Shahar",
      "footer_text3" => "Menyu",
      "footer_text4" => "Bosh sahifa",
      "footer_text5" => "Biz haqimizda",
      "footer_text6" => "Yangiliklar",
      "footer_text7" => "Catigory",
      "footer_text8" => "Kontakt",
      "footer_text9" => "Mahhur shaharlar",
      "footer_text10" => "Tailand",
      "footer_text11" => "Daubai",
      "footer_text12" => "Turkiya",
      "footer_text13" => "Shvedsiya",
      "footer_text14" => "Gruziya",
      "footer_text15" => "Vetnam",
      "footer_text16" => "Biz ijtimoiy tarmoqlardamiz",
      "modal-text" => "So'rovingiz muvaffaqiyatli jo'natildi✅",

      "intro_text1" => "Tour bo'limi",
      "intro_text2" => "Bosh sahifa",
      "intro_text3" => "Bizdagi tourlar bo'limi",
      "tour_lang1" => "Tavsif",
      "tour_lang2" => "Bu kabi sayohatlar sayyohlarga dunyoning turli burchaklarida yashayotgan xalqlarning madaniyati va turmush tarzini chuqurroq tushunish imkoniyatini beradi. Bunday tajribalar odamlarni boshqa mamlakatlarning boy tarixi va rang-barang madaniyatlariga yaqindan guvoh bo'lishga olib keladi. Sayohatchilar, odatda, tarixiy qadriyatlarni, jumladan qadimgi obidalar, muzeylar va san'at galereyalari kabi diqqatga sazovor joylarni ziyorat qilishadi. Bu yerlarda ular mahalliy san'at asarlari va tarixiy yodgorliklarni ko'rib, ularning tarixi va ahamiyati haqida ma'lumot oladilar.",
      "tour_lang3" => "Sayohatlar, shubhasiz, odamlarga dunyoni ko'rish va yangi madaniyatlarni tushunish imkoniyatini beradi. Sayohat paytida inson yangi joylarni kashf etadi, turli xil madaniyatlar va urf-odatlarni o'rganadi, bu esa uning dunyoqarashini boyitadi. Sayohatlar, shuningdek, yangi do'stlar orttirish va turli insonlar bilan muloqot qilish imkoniyatini yaratadi, bu esa ijtimoiy tarmoqlarni kengaytiradi va odamlararo munosabatlarni mustahkamlaydi. Bunday sarguzashtlar har bir kishining hayot tajribasini oshiradi, yangi ko'nikma va bilimlarni o'rgatadi.",
      "tour_lang4" => "Gruziya",
      "tour_lang5" => "Nima uchun TOURFETTO ni tanlashingiz kerak",
      "tour_lang6" => "Yashirin to'lovlarsiz eng yaxshi narx kafolati",
      "tour_lang7" => "24/7 mijozlarni qo‘llab-quvvatlash",
      "tour_lang8" => "Egalarining halol reytingi",
      "tour_lang9" => "Faqat haqiqiy mehmonlarning sharhlari va baholari",
      "tour_lang10" => "Narxi:",
      "tour_lang11" => "Boshqa turlar",

      "intro_text4" => "Bizdagi Yangiliklar",
      "intro_text6" => "Yangiliklar bo'limi",
      "news_text1" => "10 kun Tainlant da",
      "news_text2" => "tajribalarini yaratishga intiladi. Shu bois, biz sizga Ispaniya, Italiya va Gretsiyadagi yangi va ajoyib sayohat paketlarini taqdim etishdan mamnunmiz. Bu mo'jazgina tavsif sizga ushbu go'zal mamlakatlardagi sayohatlarimizning qanday bo'lishi haqida tasavvurga ega bo'lishingizda yordam beradi.",
      "news_text3" => "Ispaniya: Ispaniya, o'zining boy tarixi, rang-barang madaniyati va hayratlanarli me'morchiligi bilan mashhur. Bu yerda siz eski shaharlar, qadimgi qasrlar va zamonaviy san'at asarlarini topasiz. Barselona shahridagi Gaudi me'morchiligi va Madridning tarixiy markazlari kabi diqqatga sazovor joylar sizni kutmoqda. Shuningdek, flamenko raqslari va mazali ispan taomlari sizni hayratda qoldiradi.",
      "news_text4" => "Yangiliklar",
      "news_text5" => "Yangi tur",

      "intro_text7" => "Bizdagi barcha turlar bo'limi",
      "all_tour_text" => "Mashhur Yo'nalishlar",

      "intro_text8" => "Yangiliklar bo'limi",
      "intro_text9" => "Barcha categorylar",

      "more" => "Batafsil",
      "" => "",

];
